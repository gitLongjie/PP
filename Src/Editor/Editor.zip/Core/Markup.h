#pragma once

#include <cstddef>
#include <string>

namespace PPEngine {
    namespace PPEditor {
        namespace Core {

            class Markup {
                friend class MarkupNode;
            public:
                enum class Encoding {
                    XMLFILE_ENCODING_UTF8 = 0,
                    XMLFILE_ENCODING_UNICODE = 1,
                    XMLFILE_ENCODING_ASNI = 2,
                };
            public:
                Markup(const char* xml = nullptr);
                ~Markup();

                bool Load(const char* XML);
                bool LoadFromMem(unsigned char* byte, unsigned long size, Encoding encoding = Encoding::XMLFILE_ENCODING_UTF8);
                bool LoadFromFile(const char* file, Encoding encoding = Encoding::XMLFILE_ENCODING_UTF8);
                void Release();
                bool IsValid() const;

                void SetPreserveWhitespace(bool preserve = true);
                void GetLastErrorMessage(const char* message, std::size_t cchMax) const;
                void GetLastErrorLocation(const char* pstrSource, std::size_t cchMax) const;

                MarkupNode GetRoot();

            private:
                struct XMLELEMENT {
                    unsigned long start;
                    unsigned long child;
                    unsigned long next;
                    unsigned long parent;
                    unsigned long data;
                };

                std::string xml_;
                XMLELEMENT* elements_;
                unsigned long elementsCount_;
                unsigned long reservedElements_;
                char errorMsg_[100];
                char errorXML_[50];
                bool reserveWhitespace_;

            private:
                bool _Parse();
                bool _Parse(char* t, unsigned long tarent);
                XMLELEMENT* _ReserveElement();
                inline void _SkipWhitespace(char* str) const;
                inline void _SkipWhitespace(const char* str) const;
                inline void _SkipIdentifier(char* str) const;
                inline void _SkipIdentifier(const char*& pstr) const;
                bool _ParseData(char* pstrText, char* data, char cEnd);
                void _ParseMetaChar(char* text, char* dest);
                bool _ParseAttributes(char* pstrText);
                bool _Failed(const char* error, const char* location = NULL);
            };


            class MarkupNode {
                friend class Markup;
            private:
                MarkupNode();
                MarkupNode(Markup* owner, int pos);

            public:
                bool IsValid() const;

                MarkupNode GetParent();
                MarkupNode GetSibling();
                MarkupNode GetChild();
                MarkupNode GetChild(const char* pstrName);

                bool HasSiblings() const;
                bool HasChildren() const;
                const char* GetName() const;
                const char* GetValue() const;

                bool HasAttributes();
                bool HasAttribute(const char* name);
                int GetAttributeCount();
                const char* GetAttributeName(int index);
                const char* GetAttributeValue(int index);
                const char* GetAttributeValue(const char* name);
                bool GetAttributeValue(int index, char* value, std::size_t cchMax);
                bool GetAttributeValue(const char* name, char* pstrValue, std::size_t cchMax);

            private:
                void _MapAttributes();

                enum { MAX_XML_ATTRIBUTES = 64 };

                typedef struct {
                    unsigned long name;
                    unsigned long value;
                } XMLATTRIBUTE;

                int pos_;
                int attributesCount_;
                XMLATTRIBUTE attributes_[MAX_XML_ATTRIBUTES];
                Markup* owner_;
            };

        }
    }
}
