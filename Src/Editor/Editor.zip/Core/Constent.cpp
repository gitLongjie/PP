#include "Editor/Core/Constent.h"

namespace PPEngine {
	namespace PPEditor {
		namespace Core {
			const char* kCtrEdit = "Edit";
			const char* kCtrList = "List";
			const char* kCtrText = "Text";
			const char* kCtrComb = "Combo";
			const char* kCtrLabel = "Label";
			
			const char* kCtrButton = "Button";
			const char* kCtrOption = "Option";
			const char* kCtrSlider = "Slider";
			
			const char* kCtrControl = "Control";
			
			const char* kCtrListItem = "ListItem";
			const char* kCtrProgress = "Progress";
			const char* kCtrCheckBox = "CheckBox";
			const char* kCtrComboBox = "ComboBox";
			const char* kCtrDateTime = "DateTime";
			const char* kCtrTreeView = "TreeView";
			const char* kCtrTreeNode = "TreeNode";
			
			const char* kCtrContainer = "Container";
			const char* kCtrTabLayout = "TabLayout";
			const char* kCtrScrollBar = "ScrollBar";
			
			const char* kCtrListHeader = "ListHeader";
			const char* kCtrTileLayout = "TileLayout";

			const char* kCtrChildLayout = "ChildLayout";
			const char* kCtrListElement = "ListElement";

			const char* kCtrDialogLayout = "DialogLayout";

			const char* kCtrVerticalLayout = "VerticalLayout";
			const char* kCtrListHeaderItem = "ListHeaderItem";

			const char* kCtrListTextElement = "ListTextElement";

			const char* kCtrHorizontalLayout = "HorizontalLayout";
			const char* kCtrListLabelElement = "ListLabelElement";

			const char* kCtrListContainerElement = "ListContainerElement";
		}
	}
}