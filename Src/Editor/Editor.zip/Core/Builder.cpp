#include "Editor/Core/Builder.h"

#include "Core/Constent.h"
#include "Core/Logger.h"

namespace PPEngine {
    namespace PPEditor {
        namespace Core {

            Builder::Builder() : callback_(nullptr), type_(nullptr) {

            }

            Control* Builder::Create(const std::string& xml, const char* type, IBuilderCallback* callback,
                PPEngine::Core::WindowContext* pManager, Control* pParent) {

                if (HIWORD(xml.data()) != 0) {
                    if (*(xml.c_str()) == '<') {
                        if (!xml_.Load(xml.c_str())) return nullptr;
                    } else {
                        if (!xml_.LoadFromFile(xml.c_str())) return nullptr;
                    }
                } else {
                    HRSRC hResource = ::FindResource(PPEngine::Core::WindowContext::GetResourceDll(), xml.c_str(), type);
                    if (hResource == nullptr) return nullptr;
                    HGLOBAL hGlobal = ::LoadResource(PPEngine::Core::WindowContext::GetResourceDll(), hResource);
                    if (hGlobal == nullptr) {
                        FreeResource(hResource);
                        return nullptr;
                    }

                    callback_ = callback;
                    if (!xml_.LoadFromMem((BYTE*)::LockResource(hGlobal), ::SizeofResource(PPEngine::Core::WindowContext::GetResourceDll(), hResource))) return nullptr;
                    ::FreeResource(hResource);
                    type_ = type;
                }

                return Create(callback, pManager, pParent);
            }

            Control* Builder::Create(IBuilderCallback* callback, PPEngine::Core::WindowContext* pManager, Control* pParent) {
                callback_ = callback;
                MarkupNode root = xml_.GetRoot();
                if (!root.IsValid()) return nullptr;

                if (pManager) {
                    const char* strClass = nullptr;
                    int nAttributes = 0;
                    const char* pstrName = nullptr;
                    const char* pstrValue = nullptr;
                    char* pstr = nullptr;
                    for (MarkupNode node = root.GetChild(); node.IsValid(); node = node.GetSibling()) {
                        strClass = node.GetName();
                        if (strcmp(strClass, "Image") == 0) {
                            nAttributes = node.GetAttributeCount();
                            const char* pImageName = nullptr;
                            const char* pImageResType = nullptr;
                            DWORD mask = 0;
                            for (int i = 0; i < nAttributes; i++) {
                                pstrName = node.GetAttributeName(i);
                                pstrValue = node.GetAttributeValue(i);
                                if (strcmp(pstrName, "name") == 0) {
                                    pImageName = pstrValue;
                                } else if (strcmp(pstrName, "restype") == 0) {
                                    pImageResType = pstrValue;
                                } else if (strcmp(pstrName, "mask") == 0) {
                                    if (*pstrValue == '#') pstrValue = ::CharNext(pstrValue);
                                    mask = strtoul(pstrValue, &pstr, 16);
                                }
                            }
                            if (pImageName) pManager->AddImage(pImageName, pImageResType, mask);
                        } else if (strcmp(strClass, "Font") == 0) {
                            nAttributes = node.GetAttributeCount();
                            const char* pFontName = nullptr;
                            int size = 12;
                            bool bold = false;
                            bool underline = false;
                            bool italic = false;
                            bool defaultfont = false;
                            for (int i = 0; i < nAttributes; i++) {
                                pstrName = node.GetAttributeName(i);
                                pstrValue = node.GetAttributeValue(i);
                                if (strcmp(pstrName, "name") == 0) {
                                    pFontName = pstrValue;
                                } else if (strcmp(pstrName, "size") == 0) {
                                    size = strtoul(pstrValue, &pstr, 10);
                                } else if (strcmp(pstrName, "bold") == 0) {
                                    bold = (strcmp(pstrValue, "true") == 0);
                                } else if (strcmp(pstrName, "underline") == 0) {
                                    underline = (strcmp(pstrValue, "true") == 0);
                                } else if (strcmp(pstrName, "italic") == 0) {
                                    italic = (strcmp(pstrValue, "true") == 0);
                                } else if (strcmp(pstrName, "default") == 0) {
                                    defaultfont = (strcmp(pstrValue, "true") == 0);
                                }
                            }
                            if (pFontName) {
                                pManager->AddFont(pFontName, size, bold, underline, italic);
                                if (defaultfont) pManager->SetDefaultFont(pFontName, size, bold, underline, italic);
                            }
                        } else if (strcmp(strClass, "Default") == 0) {
                            nAttributes = node.GetAttributeCount();
                            const char* pControlName = nullptr;
                            const char* pControlValue = nullptr;
                            for (int i = 0; i < nAttributes; i++) {
                                pstrName = node.GetAttributeName(i);
                                pstrValue = node.GetAttributeValue(i);
                                if (strcmp(pstrName, _T("name")) == 0) {
                                    pControlName = pstrValue;
                                } else if (strcmp(pstrName, _T("value")) == 0) {
                                    pControlValue = pstrValue;
                                }
                            }
                            if (pControlName) {
                                pManager->AddDefaultAttributeList(pControlName, pControlValue);
                            }
                        }
                    }

                    strClass = root.GetName();
                    if (strcmp(strClass, "Window") == 0) {
                        if (pManager->GetPaintWindow()) {
                            int nAttributes = root.GetAttributeCount();
                            for (int i = 0; i < nAttributes; i++) {
                                pstrName = root.GetAttributeName(i);
                                pstrValue = root.GetAttributeValue(i);
                                if (strcmp(pstrName, _T("size")) == 0) {
                                    char* pstr = nullptr;
                                    int cx = strtoul(pstrValue, &pstr, 10);  ASSERT(pstr);
                                    int cy = strtoul(pstr + 1, &pstr, 10);    ASSERT(pstr);
                                    pManager->SetInitSize(cx, cy);
                                } else if (strcmp(pstrName, _T("sizebox")) == 0) {
                                    RECT rcSizeBox = { 0 };
                                    char* pstr = nullptr;
                                    rcSizeBox.left = strtoul(pstrValue, &pstr, 10);  ASSERT(pstr);
                                    rcSizeBox.top = strtoul(pstr + 1, &pstr, 10);    ASSERT(pstr);
                                    rcSizeBox.right = strtoul(pstr + 1, &pstr, 10);  ASSERT(pstr);
                                    rcSizeBox.bottom = strtoul(pstr + 1, &pstr, 10); ASSERT(pstr);
                                    pManager->SetSizeBox(rcSizeBox);
                                } else if (strcmp(pstrName, _T("caption")) == 0) {
                                    RECT rcCaption = { 0 };
                                    char* pstr = nullptr;
                                    rcCaption.left = strtoul(pstrValue, &pstr, 10);  ASSERT(pstr);
                                    rcCaption.top = strtoul(pstr + 1, &pstr, 10);    ASSERT(pstr);
                                    rcCaption.right = strtoul(pstr + 1, &pstr, 10);  ASSERT(pstr);
                                    rcCaption.bottom = strtoul(pstr + 1, &pstr, 10); ASSERT(pstr);
                                    pManager->SetCaptionRect(rcCaption);
                                } else if (strcmp(pstrName, _T("roundcorner")) == 0) {
                                    char* pstr = nullptr;
                                    int cx = strtoul(pstrValue, &pstr, 10);  ASSERT(pstr);
                                    int cy = strtoul(pstr + 1, &pstr, 10);    ASSERT(pstr);
                                    pManager->SetRoundCorner(cx, cy);
                                } else if (strcmp(pstrName, _T("mininfo")) == 0) {
                                    char* pstr = nullptr;
                                    int cx = strtoul(pstrValue, &pstr, 10);  ASSERT(pstr);
                                    int cy = strtoul(pstr + 1, &pstr, 10);    ASSERT(pstr);
                                    pManager->SetMinInfo(cx, cy);
                                } else if (strcmp(pstrName, _T("maxinfo")) == 0) {
                                    char* pstr = nullptr;
                                    int cx = strtoul(pstrValue, &pstr, 10);  ASSERT(pstr);
                                    int cy = strtoul(pstr + 1, &pstr, 10);    ASSERT(pstr);
                                    pManager->SetMaxInfo(cx, cy);
                                } else if (strcmp(pstrName, _T("showdirty")) == 0) {
                                    pManager->SetShowUpdateRect(strcmp(pstrValue, _T("true")) == 0);
                                } else if (strcmp(pstrName, _T("alpha")) == 0) {
                                    pManager->SetTransparent(_ttoi(pstrValue));
                                } else if (strcmp(pstrName, _T("bktrans")) == 0) {
                                    pManager->SetBackgroundTransparent(strcmp(pstrValue, _T("true")) == 0);
                                } else if (strcmp(pstrName, _T("disabledfontcolor")) == 0) {
                                    if (*pstrValue == _T('#')) pstrValue = ::CharNext(pstrValue);
                                    char* pstr = nullptr;
                                    DWORD clrColor = strtoul(pstrValue, &pstr, 16);
                                    pManager->SetDefaultDisabledColor(clrColor);
                                } else if (strcmp(pstrName, _T("defaultfontcolor")) == 0) {
                                    if (*pstrValue == _T('#')) pstrValue = ::CharNext(pstrValue);
                                    char* pstr = nullptr;
                                    DWORD clrColor = strtoul(pstrValue, &pstr, 16);
                                    pManager->SetDefaultFontColor(clrColor);
                                } else if (strcmp(pstrName, _T("linkfontcolor")) == 0) {
                                    if (*pstrValue == _T('#')) pstrValue = ::CharNext(pstrValue);
                                    char* pstr = nullptr;
                                    DWORD clrColor = strtoul(pstrValue, &pstr, 16);
                                    pManager->SetDefaultLinkFontColor(clrColor);
                                } else if (strcmp(pstrName, _T("linkhoverfontcolor")) == 0) {
                                    if (*pstrValue == _T('#')) pstrValue = ::CharNext(pstrValue);
                                    char* pstr = nullptr;
                                    DWORD clrColor = strtoul(pstrValue, &pstr, 16);
                                    pManager->SetDefaultLinkHoverFontColor(clrColor);
                                } else if (strcmp(pstrName, _T("selectedcolor")) == 0) {
                                    if (*pstrValue == _T('#')) pstrValue = ::CharNext(pstrValue);
                                    char* pstr = nullptr;
                                    DWORD clrColor = strtoul(pstrValue, &pstr, 16);
                                    pManager->SetDefaultSelectedBkColor(clrColor);
                                }
                            }
                        }
                    }
                }
                return _Parse(&root, pParent, pManager);
            }

            Markup* Builder::GetMarkup() {
                return &xml_;
            }

            void Builder::GetLastErrorMessage(char* message, std::size_t cchMax) const {
                return xml_.GetLastErrorMessage(message, cchMax);
            }

            void Builder::GetLastErrorLocation(char* source, std::size_t cchMax) const {
                return xml_.GetLastErrorLocation(source, cchMax);
            }

            Control* Builder::_Parse(MarkupNode* pRoot, Control* pParent, PPEngine::Core::WindowContext* pManager) {
                ContainerUI* pContainer = nullptr;
                Control* pReturn = nullptr;
                for (MarkupNode node = pRoot->GetChild(); node.IsValid(); node = node.GetSibling()) {
                    const char* strClass = node.GetName();
                    if (strcmp(strClass, _T("Image")) == 0 || strcmp(strClass, _T("Font")) == 0 \
                        || strcmp(strClass, _T("Default")) == 0) continue;

                    Control* pControl = nullptr;
                    if (strcmp(strClass, _T("Include")) == 0) {
                        if (!node.HasAttributes()) continue;
                        int count = 1;
                        char* pstr = nullptr;
                        TCHAR szValue[500] = { 0 };
                        std::size_t cchLen = lengthof(szValue) - 1;
                        if (node.GetAttributeValue(_T("count"), szValue, cchLen))
                            count = strtoul(szValue, &pstr, 10);
                        cchLen = lengthof(szValue) - 1;
                        if (!node.GetAttributeValue(_T("source"), szValue, cchLen)) continue;
                        for (int i = 0; i < count; i++) {
                            Builder builder;
                            if (m_pstrtype != nullptr) { // ʹ����Դdll������Դ�ж�ȡ
                                int16_t id = (WORD)strtoul(szValue, &pstr, 10);
                                pControl = builder.Create((uint32_t)id, m_pstrtype, callback_, pManager, pParent);
                            } else {
                                pControl = builder.Create((const char*)szValue, (UINT)0, callback_, pManager, pParent);
                            }
                        }
                        continue;
                    }
                    //���ؼ�XML����
                    else if (strcmp(strClass, _T("TreeNode")) == 0) {
                        CTreeNodeUI* pParentNode = static_cast<CTreeNodeUI*>(pParent->GetInterface(_T("TreeNode")));
                        CTreeNodeUI* pNode = new CTreeNodeUI();
                        if (pParentNode) {
                            if (!pParentNode->Add(pNode)) {
                                delete pNode;
                                continue;
                            }
                        }

                        // ���пؼ�Ĭ�������ȳ�ʼ��Ĭ������
                        if (pManager) {
                            pNode->SetManager(pManager, nullptr, false);
                            const char* pDefaultAttributes = pManager->GetDefaultAttributeList(strClass);
                            if (pDefaultAttributes) {
                                pNode->ApplyAttributeList(pDefaultAttributes);
                            }
                        }

                        // �����������Բ�����Ĭ������
                        if (node.HasAttributes()) {
                            TCHAR szValue[500] = { 0 };
                            std::size_t cchLen = lengthof(szValue) - 1;
                            // Set ordinary attributes
                            int nAttributes = node.GetAttributeCount();
                            for (int i = 0; i < nAttributes; i++) {
                                pNode->SetAttribute(node.GetAttributeName(i), node.GetAttributeValue(i));
                            }
                        }

                        //�����ӽڵ㼰���ӿؼ�
                        if (node.HasChildren()) {
                            Control* pSubControl = _Parse(&node, pNode, pManager);
                            if (pSubControl && strcmp(pSubControl->GetClass(), _T("TreeNodeUI")) != 0) {
                                // 					pSubControl->SetFixedWidth(30);
                                // 					CHorizontalLayoutUI* pHorz = pNode->GetTreeNodeHoriznotal();
                                // 					pHorz->Add(new CEditUI());
                                // 					continue;
                            }
                        }

                        if (!pParentNode) {
                            CTreeViewUI* pTreeView = static_cast<CTreeViewUI*>(pParent->GetInterface(_T("TreeView")));
                            ASSERT(pTreeView);
                            if (pTreeView == nullptr) return nullptr;
                            if (!pTreeView->Add(pNode)) {
                                delete pNode;
                                continue;
                            }
                        }
                        continue;
                    } else {
                        std::size_t cchLen = _tcslen(strClass);
                        switch (cchLen) {
                        case 4:
                            if (strcmp(strClass, DUI_CTR_EDIT) == 0)                   pControl = new CEditUI;
                            else if (strcmp(strClass, DUI_CTR_LIST) == 0)              pControl = new CListUI;
                            else if (strcmp(strClass, DUI_CTR_TEXT) == 0)              pControl = new CTextUI;
                            break;
                        case 5:
                            if (strcmp(strClass, DUI_CTR_COMBO) == 0)                  pControl = new CComboUI;
                            else if (strcmp(strClass, DUI_CTR_LABEL) == 0)             pControl = new CLabelUI;
                            else if (strcmp(strClass, DUI_CTR_FLASH) == 0)             pControl = new CFlashUI;
                            break;
                        case 6:
                            if (strcmp(strClass, DUI_CTR_BUTTON) == 0)                 pControl = new CButtonUI;
                            else if (strcmp(strClass, DUI_CTR_OPTION) == 0)            pControl = new COptionUI;
                            else if (strcmp(strClass, DUI_CTR_SLIDER) == 0)            pControl = new CSliderUI;
                            break;
                        case 7:
                            if (strcmp(strClass, DUI_CTR_CONTROL) == 0)                pControl = new Control;
                            else if (strcmp(strClass, DUI_CTR_ACTIVEX) == 0)           pControl = new CActiveXUI;
                            break;
                        case 8:
                            if (strcmp(strClass, DUI_CTR_PROGRESS) == 0)               pControl = new CProgressUI;
                            else if (strcmp(strClass, DUI_CTR_RICHEDIT) == 0)          pControl = new CRichEditUI;
                            else if (strcmp(strClass, DUI_CTR_CHECKBOX) == 0)		  pControl = new CCheckBoxUI;
                            else if (strcmp(strClass, DUI_CTR_COMBOBOX) == 0)		  pControl = new CComboBoxUI;
                            else if (strcmp(strClass, DUI_CTR_DATETIME) == 0)		  pControl = new CDateTimeUI;
                            else if (strcmp(strClass, DUI_CTR_TREEVIEW) == 0)		  pControl = new CTreeViewUI;
                            break;
                        case 9:
                            if (strcmp(strClass, DUI_CTR_CONTAINER) == 0)              pControl = new CContainerUI;
                            else if (strcmp(strClass, DUI_CTR_TABLAYOUT) == 0)         pControl = new CTabLayoutUI;
                            else if (strcmp(strClass, DUI_CTR_SCROLLBAR) == 0)         pControl = new CScrollBarUI;
                            break;
                        case 10:
                            if (strcmp(strClass, DUI_CTR_LISTHEADER) == 0)             pControl = new CListHeaderUI;
                            else if (strcmp(strClass, DUI_CTR_TILELAYOUT) == 0)        pControl = new CTileLayoutUI;
                            else if (strcmp(strClass, DUI_CTR_WEBBROWSER) == 0)        pControl = new CWebBrowserUI;
                            break;
                        case 11:
                            if (strcmp(strClass, DUI_CTR_CHILDLAYOUT) == 0)			  pControl = new CChildLayoutUI;
                            break;
                        case 14:
                            if (strcmp(strClass, DUI_CTR_VERTICALLAYOUT) == 0)         pControl = new CVerticalLayoutUI;
                            else if (strcmp(strClass, DUI_CTR_LISTHEADERITEM) == 0)    pControl = new CListHeaderItemUI;
                            break;
                        case 15:
                            if (strcmp(strClass, DUI_CTR_LISTTEXTELEMENT) == 0)        pControl = new CListTextElementUI;
                            break;
                        case 16:
                            if (strcmp(strClass, DUI_CTR_HORIZONTALLAYOUT) == 0)       pControl = new CHorizontalLayoutUI;
                            else if (strcmp(strClass, DUI_CTR_LISTLABELELEMENT) == 0)  pControl = new CListLabelElementUI;
                            break;
                        case 20:
                            if (strcmp(strClass, DUI_CTR_LISTCONTAINERELEMENT) == 0)   pControl = new CListContainerElementUI;
                            break;
                        }
                        // User-supplied control factory
                        if (pControl == nullptr) {
                            CStdPtrArray* pPlugins = CPaintManagerUI::GetPlugins();
                            LPCREATECONTROL lpCreateControl = nullptr;
                            for (int i = 0; i < pPlugins->GetSize(); ++i) {
                                lpCreateControl = (LPCREATECONTROL)pPlugins->GetAt(i);
                                if (lpCreateControl != nullptr) {
                                    pControl = lpCreateControl(strClass);
                                    if (pControl != nullptr) break;
                                }
                            }
                        }
                        if (pControl == nullptr && callback_ != nullptr) {
                            pControl = callback_->CreateControl(strClass);
                        }
                    }

#ifndef _DEBUG
                    ASSERT(pControl);
#endif // _DEBUG
                    if (pControl == nullptr) {
#ifdef _DEBUG
                        ERRORLOG("δ֪�ؼ�:{}", strClass);
#else
                        continue;
#endif
                    }

                    // Add children
                    if (node.HasChildren()) {
                        _Parse(&node, pControl, pManager);
                    }
                    // Attach to parent
                    // ��ΪĳЩ���Ժ͸�������أ�����selected��������Add��������
                    if (pParent != nullptr) {
                        CTreeNodeUI* pContainerNode = static_cast<CTreeNodeUI*>(pParent->GetInterface(_T("TreeNode")));
                        if (pContainerNode)
                            pContainerNode->GetTreeNodeHoriznotal()->Add(pControl);
                        else {
                            if (pContainer == nullptr) pContainer = static_cast<IContainerUI*>(pParent->GetInterface(_T("IContainer")));
                            ASSERT(pContainer);
                            if (pContainer == nullptr) return nullptr;
                            if (!pContainer->Add(pControl)) {
                                delete pControl;
                                continue;
                            }
                        }
                    }
                    // Init default attributes
                    if (pManager) {
                        pControl->SetManager(pManager, nullptr, false);
                        const char* pDefaultAttributes = pManager->GetDefaultAttributeList(strClass);
                        if (pDefaultAttributes) {
                            pControl->ApplyAttributeList(pDefaultAttributes);
                        }
                    }
                    // Process attributes
                    if (node.HasAttributes()) {
                        TCHAR szValue[500] = { 0 };
                        std::size_t cchLen = lengthof(szValue) - 1;
                        // Set ordinary attributes
                        int nAttributes = node.GetAttributeCount();
                        for (int i = 0; i < nAttributes; i++) {
                            pControl->SetAttribute(node.GetAttributeName(i), node.GetAttributeValue(i));
                        }
                    }
                    if (pManager) {
                        pControl->SetManager(nullptr, nullptr, false);
                    }
                    // Return first item
                    if (pReturn == nullptr) pReturn = pControl;
                }
                return pReturn;
            }
        }
    }
}
