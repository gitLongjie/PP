#pragma once

#include <functional>
#include <string>
#include <glm/glm.hpp>

namespace PPEngine {
	namespace PPEditor {
		namespace Core {
			enum DuiSig {
				DuiSig_end = 0, // [marks end of message map]
				DuiSig_lwl,     // LRESULT (WPARAM, LPARAM)
				DuiSig_vn,      // void (TNotifyUI)
			};

			class Control;

			// Structure for notifications to the outside world
			typedef struct tagTNotifyUI {
				std::string type;
				std::string virtualWnd;
				Control* pSender;
				unsigned long dwTimestamp;
				glm::vec2 ptMouse;
				unsigned long wParam;
				unsigned long lParam;
			} TNotifyUI;
		

			enum class MSG_TYPE {
				MENU,
				LINK,

				TIMER,
				CLICK,

				RETURN,
				SCROLL,

				DROPDOWN,
				SETFOCUS,

				KILLFOCUS,
				ITEMCLICK,
				TABSELECT,

				ITEMSELECT,
				ITEMEXPAND,
				WINDOWINIT,
				BUTTONDOWN,
				MOUSEENTER,
				MOUSELEAVE,

				TEXTCHANGED,
				HEADERCLICK,
				ITEMDBCLICK,
				SHOWACTIVEX,

				ITEMCOLLAPSE,
				ITEMACTIVATE,
				VALUECHANGED,

				SELECTCHANGED,
            };

			//�ṹ����
			struct MSGMAP_ENTRY //����һ���ṹ�壬�������Ϣ��Ϣ
			{
				MSG_TYPE msgType;          // DUI��Ϣ����
				std::string ctrlName;         // �ؼ�����
				unsigned int       nSig;              // ��Ǻ���ָ������
				std::function<void()>   callback;               // ָ������ָ��
			};

			extern const char* kCtrEdit;
			extern const char* kCtrList;
			extern const char* kCtrText;
			extern const char* kCtrComb;
			extern const char* kCtrLabel;
			
			extern const char* kCtrButton;
			extern const char* kCtrOption;
			extern const char* kCtrSlider;
			
			extern const char* kCtrControl;
			
			extern const char* kCtrListItem;
			extern const char* kCtrProgress; 
			extern const char* kCtrCheckBox;
			extern const char* kCtrComboBox;
			extern const char* kCtrDateTime;
			extern const char* kCtrTreeView;
			extern const char* kCtrTreeNode;
			
			extern const char* kCtrContainer;
			extern const char* kCtrTabLayout;
			extern const char* kCtrScrollBar;
			
			extern const char* kCtrListHeader;
			extern const char* kCtrTileLayout;
			
			extern const char* kCtrChildLayout;
			extern const char* kCtrListElement;
			
			extern const char* kCtrDialogLayout;
			
			extern const char* kCtrVerticalLayout;
			extern const char* kCtrListHeaderItem;
			
			extern const char* kCtrListTextElement;
			
			extern const char* kCtrHorizontalLayout;
			extern const char* kCtrListLabelElement;
			
			extern const char* kCtrListContainerElement;

		}
	}
}
