#pragma once

#include <string>

#include "Core/WindowContext.h"
#include "Editor/Core/Markup.h"

namespace PPEngine {
    namespace PPEditor {
        namespace Core {
            class Control;

            class IBuilderCallback {
            public:
                virtual Control* CreateControl(const char* pstrClass) = 0;
            };


            class Builder {
            public:
                Builder();
                Control* Create(const std::string& xml, const char* type = nullptr, IBuilderCallback* callback = nullptr,
                    PPEngine::Core::WindowContext* pManager = nullptr, Control* pParent = nullptr);
                Control* Create(IBuilderCallback* callback = nullptr, PPEngine::Core::WindowContext* pManager = nullptr,
                    Control* pParent = nullptr);

                Markup* GetMarkup();

                void GetLastErrorMessage(char* message, std::size_t cchMax) const;
                void GetLastErrorLocation(char* source, std::size_t cchMax) const;
            private:
                Control* _Parse(MarkupNode* parent, Control* pParent = nullptr, PPEngine::Core::WindowContext* pManager = nullptr);

                Markup xml_;
                IBuilderCallback* callback_;
                std::string type_;
            };
        }
    }
}

