#include "Editor/Core/Markup.h"

#include <stdio.h>
#include <string.h>

#ifndef TRACE
#define TRACE
#endif

///////////////////////////////////////////////////////////////////////////////////////
DECLARE_HANDLE(HZIP);	// An HZIP identifies a zip file that has been opened
typedef DWORD ZRESULT;
typedef struct
{ 
    int index;                 // index of this file within the zip
    char name[MAX_PATH];       // filename within the zip
    DWORD attr;                // attributes, as in GetFileAttributes.
    FILETIME atime,ctime,mtime;// access, create, modify filetimes
    long comp_size;            // sizes of item, compressed and uncompressed. These
    long unc_size;             // may be -1 if not yet known (e.g. being streamed in)
} ZIPENTRY;
typedef struct
{ 
    int index;                 // index of this file within the zip
    TCHAR name[MAX_PATH];      // filename within the zip
    DWORD attr;                // attributes, as in GetFileAttributes.
    FILETIME atime,ctime,mtime;// access, create, modify filetimes
    long comp_size;            // sizes of item, compressed and uncompressed. These
    long unc_size;             // may be -1 if not yet known (e.g. being streamed in)
} ZIPENTRYW;
#define OpenZip OpenZipU
#define CloseZip(hz) CloseZipU(hz)
extern HZIP OpenZipU(void *z,unsigned int len,DWORD flags);
extern ZRESULT CloseZipU(HZIP hz);
#ifdef _UNICODE
#define ZIPENTRY ZIPENTRYW
#define GetZipItem GetZipItemW
#define FindZipItem FindZipItemW
#else
#define GetZipItem GetZipItemA
#define FindZipItem FindZipItemA
#endif
extern ZRESULT GetZipItemA(HZIP hz, int index, ZIPENTRY *ze);
extern ZRESULT GetZipItemW(HZIP hz, int index, ZIPENTRYW *ze);
extern ZRESULT FindZipItemA(HZIP hz, const TCHAR *name, bool ic, int *index, ZIPENTRY *ze);
extern ZRESULT FindZipItemW(HZIP hz, const TCHAR *name, bool ic, int *index, ZIPENTRYW *ze);
extern ZRESULT UnzipItem(HZIP hz, int index, void *dst, unsigned int len, DWORD flags);
///////////////////////////////////////////////////////////////////////////////////////

namespace PPEngine {
    namespace PPEditor {
        namespace Core {

            ///////////////////////////////////////////////////////////////////////////////////////
            //
            //
            //

            MarkupNode::MarkupNode() : owner_(NULL) {}

            MarkupNode::MarkupNode(Markup* owner, int pos) : owner_(owner), pos_(pos), attributesCount_(0) {}

            MarkupNode MarkupNode::GetSibling() {
                if (owner_ == NULL) return MarkupNode();
                unsigned long pos = owner_->elements_[pos_].next;
                if (pos == 0) return MarkupNode();
                return MarkupNode(owner_, pos);
            }

            bool MarkupNode::HasSiblings() const {
                if (owner_ == NULL) return false;
                unsigned long pos = owner_->elements_[pos_].next;
                return pos > 0;
            }

            MarkupNode MarkupNode::GetChild() {
                if (owner_ == NULL) return MarkupNode();
                unsigned long pos = owner_->elements_[pos_].child;
                if (pos == 0) return MarkupNode();
                return MarkupNode(owner_, pos);
            }

            MarkupNode MarkupNode::GetChild(const char* pstrName) {
                if (owner_ == NULL) return MarkupNode();
                unsigned long pos = owner_->elements_[pos_].child;
                while (pos != 0) {
                    if (strcmp(owner_->XML_ + owner_->elements_[pos].start, pstrName) == 0) {
                        return MarkupNode(owner_, pos);
                    }
                    pos = owner_->elements_[pos].next;
                }
                return MarkupNode();
            }

            bool MarkupNode::HasChildren() const {
                if (owner_ == NULL) return false;
                return owner_->elements_[pos_].child != 0;
            }

            MarkupNode MarkupNode::GetParent() {
                if (owner_ == NULL) return MarkupNode();
                unsigned long pos = owner_->elements_[pos_].parent;
                if (pos == 0) return MarkupNode();
                return MarkupNode(owner_, pos);
            }

            bool MarkupNode::IsValid() const {
                return owner_ != NULL;
            }

            const char* MarkupNode::GetName() const {
                if (owner_ == NULL) return NULL;
                return owner_->XML_ + owner_->elements_[pos_].start;
            }

            const char* MarkupNode::GetValue() const {
                if (owner_ == NULL) return NULL;
                return owner_->XML_ + owner_->elements_[pos_].data;
            }

            const char* MarkupNode::GetAttributeName(int iIndex) {
                if (owner_ == NULL) return NULL;
                if (attributesCount_ == 0) _MapAttributes();
                if (iIndex < 0 || iIndex >= attributesCount_) return "";
                return owner_->XML_ + attributes_[iIndex].name;
            }

            const char* MarkupNode::GetAttributeValue(int iIndex) {
                if (owner_ == NULL) return NULL;
                if (attributesCount_ == 0) _MapAttributes();
                if (iIndex < 0 || iIndex >= attributesCount_) return "";
                return owner_->XML_ + attributes_[iIndex].value;
            }

            const char* MarkupNode::GetAttributeValue(const char* pstrName) {
                if (owner_ == NULL) return NULL;
                if (attributesCount_ == 0) _MapAttributes();
                for (int i = 0; i < attributesCount_; i++) {
                    if (strcmp((const char*)(owner_->XML_ + attributes_[i].name), pstrName) == 0) return owner_->XML_ + attributes_[i].value;
                }
                return "";
            }

            bool MarkupNode::GetAttributeValue(int iIndex, char* value, std::size_t cchMax) {
                if (owner_ == NULL) return false;
                if (attributesCount_ == 0) _MapAttributes();
                if (iIndex < 0 || iIndex >= attributesCount_) return false;
                strncpy(value, owner_->XML_ + attributes_[iIndex].value, cchMax);
                return true;
            }

            bool MarkupNode::GetAttributeValue(const char* pstrName, char* value, std::size_t cchMax) {
                if (owner_ == NULL) return false;
                if (attributesCount_ == 0) _MapAttributes();
                for (int i = 0; i < attributesCount_; i++) {
                    if (strcmp(owner_->XML_ + attributes_[i].name, pstrName) == 0) {
                        strncpy(value, owner_->XML_ + attributes_[i].value, cchMax);
                        return true;
                    }
                }
                return false;
            }

            int MarkupNode::GetAttributeCount() {
                if (owner_ == NULL) return 0;
                if (attributesCount_ == 0) _MapAttributes();
                return attributesCount_;
            }

            bool MarkupNode::HasAttributes() {
                if (owner_ == NULL) return false;
                if (attributesCount_ == 0) _MapAttributes();
                return attributesCount_ > 0;
            }

            bool MarkupNode::HasAttribute(const char* pstrName) {
                if (owner_ == NULL) return false;
                if (attributesCount_ == 0) _MapAttributes();
                for (int i = 0; i < attributesCount_; i++) {
                    if (strcmp(owner_->XML_ + attributes_[i].name, pstrName) == 0) return true;
                }
                return false;
            }

            void MarkupNode::_MapAttributes() {
                attributesCount_ = 0;
                const char* pstr = owner_->XML_ + owner_->elements_[pos_].start;
                const char* pstrEnd = owner_->XML_ + owner_->elements_[pos_].data;
                pstr += strlen(pstr) + 1;
                while (pstr < pstrEnd) {
                    owner_->_SkipWhitespace(pstr);
                    attributes_[attributesCount_].name = pstr - owner_->XML_;
                    pstr += strlen(pstr) + 1;
                    owner_->_SkipWhitespace(pstr);
                    if (*pstr++ != ('\"')) return; // if( *pstr != ('\"') ) { pstr = ::CharNext(pstr); return; }

                    attributes_[attributesCount_++].value = pstr - owner_->XML_;
                    if (attributesCount_ >= MAX_XML_ATTRIBUTES) return;
                    pstr += strlen(pstr) + 1;
                }
            }


            ///////////////////////////////////////////////////////////////////////////////////////
            //
            //
            //

            Markup::Markup(const char* pstrXML) {
                XML_ = NULL;
                elements_ = NULL;
                elementsCount_ = 0;
                reserveWhitespace_ = true;
                if (pstrXML != NULL) Load(pstrXML);
            }

            Markup::~Markup() {
                Release();
            }

            bool Markup::IsValid() const {
                return elements_ != NULL;
            }

            void Markup::SetPreserveWhitespace(bool preserve) {
                reserveWhitespace_ = preserve;
            }

            bool Markup::Load(const char* xml) {
                Release();
                xml_ = xml;

                bool bRes = _Parse();
                if (!bRes) Release();
                return bRes;
            }

            bool Markup::LoadFromMem(unsigned char* byte, unsigned long size, Encoding encoding) {
#ifdef _UNICODE
                if (encoding == XMLFILE_ENCODING_UTF8) {
                    if (dwSize >= 3 && pByte[0] == 0xEF && pByte[1] == 0xBB && pByte[2] == 0xBF) {
                        pByte += 3; dwSize -= 3;
                    }
                    DWORD nWide = ::MultiByteToWideChar(CP_UTF8, 0, (LPCSTR)pByte, dwSize, NULL, 0);

                    XML_ = static_cast<char*>(malloc((nWide + 1) * sizeof(TCHAR)));
                    ::MultiByteToWideChar(CP_UTF8, 0, (LPCSTR)pByte, dwSize, XML_, nWide);
                    XML_[nWide] = ('\0');
                } else if (encoding == XMLFILE_ENCODING_ASNI) {
                    DWORD nWide = ::MultiByteToWideChar(CP_ACP, 0, (LPCSTR)pByte, dwSize, NULL, 0);

                    XML_ = static_cast<char*>(malloc((nWide + 1) * sizeof(TCHAR)));
                    ::MultiByteToWideChar(CP_ACP, 0, (LPCSTR)pByte, dwSize, XML_, nWide);
                    XML_[nWide] = ('\0');
                } else {
                    if (dwSize >= 2 && ((pByte[0] == 0xFE && pByte[1] == 0xFF) || (pByte[0] == 0xFF && pByte[1] == 0xFE))) {
                        dwSize = dwSize / 2 - 1;

                        if (pByte[0] == 0xFE && pByte[1] == 0xFF) {
                            pByte += 2;

                            for (DWORD nSwap = 0; nSwap < dwSize; nSwap++) {
                                register CHAR nTemp = pByte[(nSwap << 1) + 0];
                                pByte[(nSwap << 1) + 0] = pByte[(nSwap << 1) + 1];
                                pByte[(nSwap << 1) + 1] = nTemp;
                            }
                        } else {
                            pByte += 2;
                        }

                        XML_ = static_cast<char*>(malloc((dwSize + 1) * sizeof(TCHAR)));
                        ::CopyMemory(XML_, pByte, dwSize * sizeof(TCHAR));
                        XML_[dwSize] = ('\0');

                        pByte -= 2;
                    }
                }
#else // !_UNICODE
                if (encoding == XMLFILE_ENCODING_UTF8) {
                    if (dwSize >= 3 && pByte[0] == 0xEF && pByte[1] == 0xBB && pByte[2] == 0xBF) {
                        pByte += 3; dwSize -= 3;
                    }
                    DWORD nWide = ::MultiByteToWideChar(CP_UTF8, 0, (LPCSTR)pByte, dwSize, NULL, 0);

                    LPWSTR w_str = static_cast<LPWSTR>(malloc((nWide + 1) * sizeof(WCHAR)));
                    ::MultiByteToWideChar(CP_UTF8, 0, (LPCSTR)pByte, dwSize, w_str, nWide);
                    w_str[nWide] = L'\0';

                    DWORD wide = ::WideCharToMultiByte(CP_ACP, 0, (LPCWSTR)w_str, nWide, NULL, 0, NULL, NULL);

                    XML_ = static_cast<char*>(malloc((wide + 1) * sizeof(TCHAR)));
                    ::WideCharToMultiByte(CP_ACP, 0, (LPCWSTR)w_str, nWide, XML_, wide, NULL, NULL);
                    XML_[wide] = ('\0');

                    free(w_str);
                } else if (encoding == XMLFILE_ENCODING_UNICODE) {
                    if (dwSize >= 2 && ((pByte[0] == 0xFE && pByte[1] == 0xFF) || (pByte[0] == 0xFF && pByte[1] == 0xFE))) {
                        dwSize = dwSize / 2 - 1;

                        if (pByte[0] == 0xFE && pByte[1] == 0xFF) {
                            pByte += 2;

                            for (DWORD nSwap = 0; nSwap < dwSize; nSwap++) {
                                register CHAR nTemp = pByte[(nSwap << 1) + 0];
                                pByte[(nSwap << 1) + 0] = pByte[(nSwap << 1) + 1];
                                pByte[(nSwap << 1) + 1] = nTemp;
                            }
                        } else {
                            pByte += 2;
                        }

                        DWORD nWide = ::WideCharToMultiByte(CP_ACP, 0, (LPCWSTR)pByte, dwSize, NULL, 0, NULL, NULL);
                        XML_ = static_cast<char*>(malloc((nWide + 1) * sizeof(TCHAR)));
                        ::WideCharToMultiByte(CP_ACP, 0, (LPCWSTR)pByte, dwSize, XML_, nWide, NULL, NULL);
                        XML_[nWide] = ('\0');

                        pByte -= 2;
                    }
                } else {
                    XML_ = static_cast<char*>(malloc((dwSize + 1) * sizeof(TCHAR)));
                    ::CopyMemory(XML_, pByte, dwSize * sizeof(TCHAR));
                    XML_[dwSize] = ('\0');
                }
#endif // _UNICODE

                bool bRes = _Parse();
                if (!bRes) Release();
                return bRes;
            }

            bool Markup::LoadFromFile(const char* pstrFilename, Encoding encoding) {
                Release();
                CDuiString sFile = CPaintManagerUI::GetResourcePath();
                if (CPaintManagerUI::GetResourceZip().IsEmpty()) {
                    sFile += pstrFilename;
                    HANDLE hFile = ::CreateFile(sFile, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
                    if (hFile == INVALID_HANDLE_VALUE) return _Failed(("Error opening file"));
                    DWORD dwSize = ::GetFileSize(hFile, NULL);
                    if (dwSize == 0) return _Failed(("File is empty"));
                    if (dwSize > 4096 * 1024) return _Failed(("File too large"));

                    DWORD dwRead = 0;
                    BYTE* pByte = new BYTE[dwSize];
                    ::ReadFile(hFile, pByte, dwSize, &dwRead, NULL);
                    ::CloseHandle(hFile);

                    if (dwRead != dwSize) {
                        delete[] pByte;
                        Release();
                        return _Failed(("Could not read file"));
                    }
                    bool ret = LoadFromMem(pByte, dwSize, encoding);
                    delete[] pByte;

                    return ret;
                } else {
                    sFile += CPaintManagerUI::GetResourceZip();
                    HZIP hz = NULL;
                    if (CPaintManagerUI::IsCachedResourceZip()) hz = (HZIP)CPaintManagerUI::GetResourceZipHandle();
                    else hz = OpenZip((void*)sFile.GetData(), 0, 2);
                    if (hz == NULL) return _Failed(("Error opening zip file"));
                    ZIPENTRY ze;
                    int i;
                    if (FindZipItem(hz, pstrFilename, true, &i, &ze) != 0) return _Failed(("Could not find ziped file"));
                    DWORD dwSize = ze.unc_size;
                    if (dwSize == 0) return _Failed(("File is empty"));
                    if (dwSize > 4096 * 1024) return _Failed(("File too large"));
                    BYTE* pByte = new BYTE[dwSize];
                    int res = UnzipItem(hz, i, pByte, dwSize, 3);
                    if (res != 0x00000000 && res != 0x00000600) {
                        delete[] pByte;
                        if (!CPaintManagerUI::IsCachedResourceZip()) CloseZip(hz);
                        return _Failed(("Could not unzip file"));
                    }
                    if (!CPaintManagerUI::IsCachedResourceZip()) CloseZip(hz);
                    bool ret = LoadFromMem(pByte, dwSize, encoding);
                    delete[] pByte;

                    return ret;
                }
            }

            void Markup::Release() {
                if (XML_ != NULL) free(XML_);
                if (elements_ != NULL) free(elements_);
                XML_ = NULL;
                elements_ = NULL;
                elementsCount_;
            }

            void Markup::GetLastErrorMessage(char* pstrMessage, std::size_t cchMax) const {
                strncpy(pstrMessage, m_szErrorMsg, cchMax);
            }

            void Markup::GetLastErrorLocation(char* pstrSource, std::size_t cchMax) const {
                strncpy(pstrSource, m_szErrorXML, cchMax);
            }

            MarkupNode Markup::GetRoot() {
                if (elementsCount_ == 0) return MarkupNode();
                return MarkupNode(this, 1);
            }

            bool Markup::_Parse() {
                _ReserveElement(); // Reserve index 0 for errors
                ::ZeroMemory(m_szErrorMsg, sizeof(m_szErrorMsg));
                ::ZeroMemory(m_szErrorXML, sizeof(m_szErrorXML));
                char* pstrXML = XML_;
                return _Parse(pstrXML, 0);
            }

            bool Markup::_Parse(char*& pstrText, unsigned long parent) {
                _SkipWhitespace(pstrText);
                unsigned long iPrevious = 0;
                for (; ; ) {
                    if (*pstrText == ('\0') && parent <= 1) return true;
                    _SkipWhitespace(pstrText);
                    if (*pstrText != ('<')) return _Failed(("Expected start tag"), pstrText);
                    if (pstrText[1] == ('/')) return true;
                    *pstrText++ = ('\0');
                    _SkipWhitespace(pstrText);
                    // Skip comment or processing directive
                    if (*pstrText == ('!') || *pstrText == ('?')) {
                        TCHAR ch = *pstrText;
                        if (*pstrText == ('!')) ch = ('-');
                        while (*pstrText != ('\0') && !(*pstrText == ch && *(pstrText + 1) == ('>'))) pstrText = ::CharNext(pstrText);
                        if (*pstrText != ('\0')) pstrText += 2;
                        _SkipWhitespace(pstrText);
                        continue;
                    }
                    _SkipWhitespace(pstrText);
                    // Fill out element structure
                    XMLELEMENT* pEl = _ReserveElement();
                    unsigned long pos = pEl - elements_;
                    pEl->start = pstrText - XML_;
                    pEl->parent = parent;
                    pEl->next = pEl->child = 0;
                    if (iPrevious != 0) elements_[iPrevious].next = pos;
                    else if (parent > 0) elements_[parent].child = pos;
                    iPrevious = pos;
                    // Parse name
                    const char* pstrName = pstrText;
                    _SkipIdentifier(pstrText);
                    char* pstrNameEnd = pstrText;
                    if (*pstrText == ('\0')) return _Failed(("Error parsing element name"), pstrText);
                    // Parse attributes
                    if (!_ParseAttributes(pstrText)) return false;
                    _SkipWhitespace(pstrText);
                    if (pstrText[0] == ('/') && pstrText[1] == ('>')) {
                        pEl->data = pstrText - XML_;
                        *pstrText = ('\0');
                        pstrText += 2;
                    } else {
                        if (*pstrText != ('>')) return _Failed(("Expected start-tag closing"), pstrText);
                        // Parse node data
                        pEl->data = ++pstrText - XML_;
                        char* pstrDest = pstrText;
                        if (!_ParseData(pstrText, pstrDest, ('<'))) return false;
                        // Determine type of next element
                        if (*pstrText == ('\0') && parent <= 1) return true;
                        if (*pstrText != ('<')) return _Failed(("Expected end-tag start"), pstrText);
                        if (pstrText[0] == ('<') && pstrText[1] != ('/')) {
                            if (!_Parse(pstrText, pos)) return false;
                        }
                        if (pstrText[0] == ('<') && pstrText[1] == ('/')) {
                            *pstrDest = ('\0');
                            *pstrText = ('\0');
                            pstrText += 2;
                            _SkipWhitespace(pstrText);
                            std::size_t cchName = pstrNameEnd - pstrName;
                            if (_tcsncmp(pstrText, pstrName, cchName) != 0) return _Failed(("Unmatched closing tag"), pstrText);
                            pstrText += cchName;
                            _SkipWhitespace(pstrText);
                            if (*pstrText++ != ('>')) return _Failed(("Unmatched closing tag"), pstrText);
                        }
                    }
                    *pstrNameEnd = ('\0');
                    _SkipWhitespace(pstrText);
                }
            }

            Markup::XMLELEMENT* Markup::_ReserveElement() {
                if (elementsCount_ == 0) m_nReservedElements = 0;
                if (elementsCount_ >= m_nReservedElements) {
                    m_nReservedElements += (m_nReservedElements / 2) + 500;
                    elements_ = static_cast<XMLELEMENT*>(realloc(elements_, m_nReservedElements * sizeof(XMLELEMENT)));
                }
                return &elements_[elementsCount_++];
            }

            void Markup::_SkipWhitespace(const char*& pstr) const {
                while (*pstr > ('\0') && *pstr <= (' ')) pstr = ::CharNext(pstr);
            }

            void Markup::_SkipWhitespace(char*& pstr) const {
                while (*pstr > ('\0') && *pstr <= (' ')) pstr = ::CharNext(pstr);
            }

            void Markup::_SkipIdentifier(const char*& pstr) const {
                // ����ֻ����Ӣ�ģ�������������û������
                while (*pstr != ('\0') && (*pstr == ('_') || *pstr == (':') || _istalnum(*pstr))) pstr = ::CharNext(pstr);
            }

            void Markup::_SkipIdentifier(char*& pstr) const {
                // ����ֻ����Ӣ�ģ�������������û������
                while (*pstr != ('\0') && (*pstr == ('_') || *pstr == (':') || _istalnum(*pstr))) pstr = ::CharNext(pstr);
            }

            bool Markup::_ParseAttributes(char*& pstrText) {
                if (*pstrText == ('>')) return true;
                *pstrText++ = ('\0');
                _SkipWhitespace(pstrText);
                while (*pstrText != ('\0') && *pstrText != ('>') && *pstrText != ('/')) {
                    _SkipIdentifier(pstrText);
                    char* pstrIdentifierEnd = pstrText;
                    _SkipWhitespace(pstrText);
                    if (*pstrText != ('=')) return _Failed(("Error while parsing attributes"), pstrText);
                    *pstrText++ = (' ');
                    *pstrIdentifierEnd = ('\0');
                    _SkipWhitespace(pstrText);
                    if (*pstrText++ != ('\"')) return _Failed(("Expected attribute value"), pstrText);
                    char* pstrDest = pstrText;
                    if (!_ParseData(pstrText, pstrDest, ('\"'))) return false;
                    if (*pstrText == ('\0')) return _Failed(("Error while parsing attribute string"), pstrText);
                    *pstrDest = ('\0');
                    if (pstrText != pstrDest) *pstrText = (' ');
                    pstrText++;
                    _SkipWhitespace(pstrText);
                }
                return true;
            }

            bool Markup::_ParseData(char*& pstrText, char*& pstrDest, char cEnd) {
                while (*pstrText != ('\0') && *pstrText != cEnd) {
                    if (*pstrText == ('&')) {
                        while (*pstrText == ('&')) {
                            _ParseMetaChar(++pstrText, pstrDest);
                        }
                        if (*pstrText == cEnd)
                            break;
                    }

                    if (*pstrText == (' ')) {
                        *pstrDest++ = *pstrText++;
                        if (!reserveWhitespace_) _SkipWhitespace(pstrText);
                    } else {
                        char* pstrTemp = ::CharNext(pstrText);
                        while (pstrText < pstrTemp) {
                            *pstrDest++ = *pstrText++;
                        }
                    }
                }
                // Make sure that MapAttributes() works correctly when it parses
                // over a value that has been transformed.
                char* pstrFill = pstrDest + 1;
                while (pstrFill < pstrText) *pstrFill++ = (' ');
                return true;
            }

            void Markup::_ParseMetaChar(char*& pstrText, char*& pstrDest) {
                if (pstrText[0] == ('a') && pstrText[1] == ('m') && pstrText[2] == ('p') && pstrText[3] == (';')) {
                    *pstrDest++ = ('&');
                    pstrText += 4;
                } else if (pstrText[0] == ('l') && pstrText[1] == ('t') && pstrText[2] == (';')) {
                    *pstrDest++ = ('<');
                    pstrText += 3;
                } else if (pstrText[0] == ('g') && pstrText[1] == ('t') && pstrText[2] == (';')) {
                    *pstrDest++ = ('>');
                    pstrText += 3;
                } else if (pstrText[0] == ('q') && pstrText[1] == ('u') && pstrText[2] == ('o') && pstrText[3] == ('t') && pstrText[4] == (';')) {
                    *pstrDest++ = ('\"');
                    pstrText += 5;
                } else if (pstrText[0] == ('a') && pstrText[1] == ('p') && pstrText[2] == ('o') && pstrText[3] == ('s') && pstrText[4] == (';')) {
                    *pstrDest++ = ('\'');
                    pstrText += 5;
                } else {
                    *pstrDest++ = ('&');
                }
            }

            bool Markup::_Failed(const char* pstrError, const char* pstrLocation) {
                // Register last error
                TRACE(("XML Error: %s"), pstrError);
                if (pstrLocation != NULL) TRACE(pstrLocation);
                strncpy(m_szErrorMsg, pstrError, (sizeof(m_szErrorMsg) / sizeof(m_szErrorMsg[0])) - 1);
                strncpy(m_szErrorXML, pstrLocation != NULL ? pstrLocation : "", lengthof(m_szErrorXML) - 1);
                return false; // Always return 'false'
            }

        }
    }
}
